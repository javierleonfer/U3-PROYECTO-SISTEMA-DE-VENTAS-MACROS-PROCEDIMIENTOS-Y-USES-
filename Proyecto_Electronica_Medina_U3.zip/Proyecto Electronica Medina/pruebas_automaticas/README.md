# Pruebas automáticas (apoyo)

Estas herramientas permiten ejecutar la lógica del proyecto en Linux x86 de 32 bits sin MASM ni Windows. Se usaron para comprobar que la versión U3 se comporta igual que la U2.

* `masm2nasm.py`: traductor **limitado** a los constructos de este proyecto. Expande macros (incluido `LOCAL`), genera los PUSH/POP de `USES` en cada `ret`, resuelve `STRUCT`, `OFFSET`, `SIZEOF` y `PTR`, y agrega una comprobación de ESP en cada vuelta del menú.
* `irvine_stub.asm`: sustituto mínimo de Irvine32 (`WriteString`, `Crlf`, `ReadString`, archivos y `MoveFileExA`) que usa llamadas al sistema de Linux. Las rutinas de archivo alteran ECX y EDX, como las API de Windows. Las banderas que dejan al regresar se pueden fijar con `-DFLAGCF=stc|clc`.
* `build.sh fuente.asm salida [stc|clc]`: traduce, ensambla con `nasm` y enlaza con `ld -m elf_i386`.
* `run_tests.py`: compila U2 (`version_unidad2/main.asm`) y U3 (`Proyecto_Electronica/main.asm`) con las dos variantes de banderas. Ejecuta 53 pruebas de extremo a extremo. Compara la salida de U2 y U3 con el mismo catálogo (binario para U2, texto para U3), revisa el contenido de `inventario.txt` y escribe `evidencias/resultados_pruebas_u3.json`.

```
python3 pruebas_automaticas/run_tests.py
```

No sustituyen la compilación con `ml.exe` ni la ejecución del `.exe` en Windows. Solo comprueban la lógica y la equivalencia entre versiones.
