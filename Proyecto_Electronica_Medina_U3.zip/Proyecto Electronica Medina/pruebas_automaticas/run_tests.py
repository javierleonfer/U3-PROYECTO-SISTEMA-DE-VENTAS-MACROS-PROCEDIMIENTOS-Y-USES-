#!/usr/bin/env python3
"""Pruebas de extremo a extremo: ejecuta U2 y U3 con las mismas entradas,
compara salidas y archivos, y verifica el resultado esperado en U3."""
import subprocess, os, shutil, struct, json, sys, time, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
INV = os.path.join(ROOT, 'datos_prueba', 'inventario_invalido.txt')
BIN = os.path.join(HERE, 'bin')
os.makedirs(BIN, exist_ok=True)
SRC = {'u2': os.path.join(ROOT, 'version_unidad2', 'main.asm'),
       'u3': os.path.join(ROOT, 'Proyecto_Electronica', 'main.asm')}
BINS = {}
for v, src in SRC.items():
    for flag, suf in (('stc', ''), ('clc', 'c')):
        BINS[v + suf] = os.path.join(BIN, v + suf)
        subprocess.run([os.path.join(HERE, 'build.sh'), src, BINS[v + suf], flag], check=True)
# Un catalogo se describe como lista de (codigo, nombre, centavos, existencia).
BASE = [('ESP-032', 'ESP32 DevKit', 18550, 10), ('RES-220', 'Resistencia 220 ohm', 125, 4), ('LED-005', 'LED rojo 5 mm', 250, 30)]

def rec(code, name, price, stock, reserved=0, pad=None):
    n = name.encode().ljust(26, b'\0')
    if pad: n = pad
    return code.encode().ljust(8, b'\0') + n + struct.pack('<HII', reserved, price, stock)

def binfile(recs):            # formato de la U2 (inventario.dat)
    return b'INV1' + struct.pack('<I', len(recs)) + b''.join(rec(*r) for r in recs)

def money(c): return '%d.%02d' % (c // 100, c % 100)
def txtfile(recs):            # formato de la U3 (inventario.txt)
    return ''.join('%s|%s|%d|%s\r\n' % (c, money(p), s, n) for c, n, p, s in recs).encode()

def parse_txt(d):
    out = []
    for line in d.decode().split('\r\n'):
        if line:
            c, p, s, n = line.split('|', 3)
            out.append((c, n, int(round(float(p) * 100)), int(s)))
    return out

def run(binp, inputs, initial=BASE, prep=None, u3=True):
    d = tempfile.mkdtemp()
    fname = 'inventario.txt' if u3 else 'inventario.dat'
    if initial is not None:
        data = initial if isinstance(initial, bytes) else (txtfile(initial) if u3 else binfile(initial))
        open(os.path.join(d, fname), 'wb').write(data)
    if prep: prep(d)
    p = subprocess.Popen([binp], cwd=d, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for item in inputs:
        if callable(item):
            time.sleep(0.15); item(d, fname); continue
        p.stdin.write((item + '\n').encode()); p.stdin.flush()
    p.stdin.close()
    out = p.stdout.read().decode('latin-1').replace('\r', '')
    p.wait(timeout=10)
    f = os.path.join(d, fname)
    data = open(f, 'rb').read() if os.path.exists(f) else None
    shutil.rmtree(d)
    return out, data, p.returncode

T = []
def t(id, parte, entrada, esperado, inputs, checks, **kw):
    T.append(dict(id=id, parte=parte, entrada=entrada, esperado=esperado, inputs=inputs, checks=checks, kw=kw))

def has(*ss):   return lambda o, d: all(s in o for s in ss)
def hasnot(s):  return lambda o, d: s not in o
def count(s, n): return lambda o, d: o.count(s) == n
def filecount(n): return lambda o, d: d is not None and len(parse_txt(d)) == n
def fileeq(b):  return lambda o, d: d == b
def stockof(code, n): return lambda o, d: any(r[0] == code and r[3] == n for r in parse_txt(d))

# --- Registro ---
t('R1', 'Registro', 'Alta USB-001, "Cable USB", 12.05, 6', 'Operacion aceptada; 4 productos al guardar',
  ['1', 'USB-001', 'Cable USB', '12.05', '6', '7', '0'], [has('Operacion aceptada.', 'Catalogo guardado'), filecount(4)])
t('R2', 'Registro', 'Alta con codigo ESP-032 (duplicado)', 'Codigo duplicado; vuelve a pedir codigo',
  ['1', 'ESP-032', 'USB-001', 'Cable', '1', '1', '0', '2'], [has('Codigo duplicado. Captura otro codigo.', 'Operacion aceptada.')])
t('R3', 'Registro', 'Codigos abc-123, AB-123, ABC-1234, ABC_123', '4 veces Dato invalido',
  ['1', 'abc-123', 'AB-123', 'ABC-1234', 'ABC_123', 'USB-001', 'X', '1', '1', '0', '2'], [count('Dato invalido', 4)])
t('R4', 'Registro', 'Nombres vacio, 3 espacios y 26 caracteres', '3 veces Dato invalido; 25 caracteres aceptado',
  ['1', 'USB-001', '', '   ', 'A' * 26, 'A' * 25, '1', '1', '0', '2'], [count('Dato invalido', 3), has('Operacion aceptada.')])
t('R5', 'Registro', 'Precios 0, 0.00, 10000, 1.2.3, 12.345, .50, -1', '7 veces Dato invalido; 9999.99 aceptado',
  ['1', 'USB-001', 'X', '0', '0.00', '10000', '1.2.3', '12.345', '.50', '-1', '9999.99', '1', '3', 'USB-001', '0', '2'],
  [count('Dato invalido', 7), has('Precio: 9999.99 MXN')])
t('R6', 'Registro', 'Existencia 101 y luego 100', 'Dato invalido; existencia 100',
  ['1', 'USB-001', 'X', '1', '101', '100', '3', 'USB-001', '0', '2'], [count('Dato invalido', 1), has('Existencia: 100')])
fill = []
for k in range(7):
    fill += ['1', 'AAA-%03d' % k, 'P%d' % k, '1', '10']
t('R7', 'Registro', 'Alta de 7 productos (total 10) y un onceavo', 'Capacidad maxima: diez productos',
  fill + ['1', '7', '0'], [count('Operacion aceptada.', 7), has('Capacidad maxima: diez productos.'), filecount(10)])
# --- Busqueda ---
t('B1', 'Busqueda', 'Buscar ESP-032', 'Ficha ESP32 DevKit 185.50 MXN, existencia 10',
  ['3', 'ESP-032', '0'], [has('ESP-032 | ESP32 DevKit', 'Precio: 185.50 MXN | Existencia: 10')])
t('B2', 'Busqueda', 'Buscar NUL-000', 'Producto no encontrado', ['3', 'NUL-000', '0'], [has('Producto no encontrado.')])
t('B3', 'Busqueda', 'Mostrar inventario (opcion 2)', 'Tres fichas; alerta solo en RES-220',
  ['2', '0'], [has('ESP-032', 'RES-220', 'LED-005'), count('ALERTA', 1)])
# --- Entradas ---
t('E1', 'Entrada', 'LED-005 (30) + 70', 'Aceptada; existencia 100',
  ['4', 'LED-005', '70', '0', '2'], [has('Operacion aceptada.', 'Existencia: 100')])
t('E2', 'Entrada', 'ESP-032 (10) + 91', 'Rechazada; existencia 10 sin cambios',
  ['4', 'ESP-032', '91', '3', 'ESP-032', '0'], [has('Operacion rechazada', 'Existencia: 10'), hasnot('Hay cambios')])
t('E3', 'Entrada', 'Cantidades 0, 101 y abc', '3 veces Dato invalido; luego 5 aceptada (15)',
  ['4', 'ESP-032', '0', '101', 'abc', '5', '0', '2'], [count('Dato invalido', 3), has('Existencia: 15')])
t('E4', 'Entrada', 'Codigo inexistente NUL-000', 'Producto no encontrado; no pide cantidad',
  ['4', 'NUL-000', '0'], [has('Producto no encontrado.'), hasnot('Cantidad entera')])
# --- Ventas ---
t('V1', 'Venta', 'ESP-032 x 2', 'Importe 371.00 MXN; existencia 8',
  ['5', 'ESP-032', '2', '6', '0', '2'], [has('Importe de la venta: 371.00 MXN', 'Existencia: 8', 'Ingresos de esta sesion: 371.00 MXN')])
t('V2', 'Venta', 'ESP-032 x 11 (hay 10)', 'Rechazada; existencia 10; ingresos 0.00',
  ['5', 'ESP-032', '11', '6', '0'], [has('Operacion rechazada', 'Ingresos de esta sesion: 0.00 MXN'), hasnot('Hay cambios')])
t('V3', 'Venta', 'ESP-032 x 10', 'Aceptada; 1855.00 MXN; existencia 0 con alerta',
  ['5', 'ESP-032', '10', '0', '2'], [has('Importe de la venta: 1855.00 MXN', 'Existencia: 0', 'ALERTA')])
t('V4', 'Venta', 'Cantidad 0 y 101', '2 veces Dato invalido; luego 1 aceptada',
  ['5', 'LED-005', '0', '101', '1', '0', '2'], [count('Dato invalido', 2), has('Importe de la venta: 2.50 MXN')])
# --- Resumen ---
t('S1', 'Resumen', 'Opcion 6 con el catalogo de ejemplo', '44 unidades; 1935.00 MXN; ingresos 0.00; alerta RES-220',
  ['6', '0'], [has('Unidades disponibles: 44', 'Valor del inventario: 1935.00 MXN', 'Ingresos de esta sesion: 0.00 MXN', 'RES-220')])
t('S2', 'Resumen', 'Venta LED-005 x 3 y resumen', '41 unidades; 1927.50 MXN; ingresos 7.50',
  ['5', 'LED-005', '3', '6', '0', '2'], [has('Unidades disponibles: 41', 'Valor del inventario: 1927.50 MXN', 'Ingresos de esta sesion: 7.50 MXN')])
big = [('AAA-%03d' % k, 'P', 999999, 100) for k in range(10)]
t('S3', 'Resumen', 'Archivo con 10 productos de 9999.99 x 100', '1000 unidades; 9999990.00 MXN',
  ['6', '0'], [has('Unidades disponibles: 1000', 'Valor del inventario: 9999990.00 MXN')], initial=big)
# --- Guardado y carga ---
t('G1', 'Guardado', 'Vender RES-220 x 1, guardar (7)', 'Guardado; archivo con RES-220 en 3',
  ['5', 'RES-220', '1', '7', '0'], [has('Catalogo guardado correctamente.'), stockof('RES-220', 3)])
t('G2', 'Carga', 'Nueva ejecucion con el archivo guardado en G1', 'Carga RES-220 con 3; ingresos 0.00',
  ['3', 'RES-220', '6', '0'], [has('Catalogo cargado y validado.', 'Existencia: 3', 'Ingresos de esta sesion: 0.00 MXN')],
  initial=[BASE[0], ('RES-220', 'Resistencia 220 ohm', 125, 3), BASE[2]])
t('G3', 'Carga', 'Archivo ausente al iniciar', 'Mensaje de error; catalogo vacio',
  ['2', '0'], [has('No se pudo cargar', 'Catalogo vacio.')], initial=None)
t('G4', 'Carga', 'inventario_invalido.dat al iniciar', 'Mensaje de error; catalogo vacio',
  ['2', '0'], [has('No se pudo cargar', 'Catalogo vacio.')], initial=open(INV, 'rb').read())
def swap_bad(d, fname): open(os.path.join(d, fname), 'wb').write(b'NO_ES_UN_INVENTARIO')
t('G5', 'Carga', 'Cambios pendientes; archivo danado; opcion 8 y descartar', 'Error; se conserva el catalogo de memoria (USB-001)',
  ['1', 'USB-001', 'Cable', '1', '1', swap_bad, '8', '1', '3', 'USB-001', '0', '2'],
  [has('No se pudo cargar', 'USB-001 | Cable')])
t('G6', 'Carga', 'Cambios pendientes; opcion 8; 0=Volver', 'No recarga; el producto nuevo sigue',
  ['1', 'USB-001', 'Cable', '1', '1', '8', '0', '3', 'USB-001', '0', '2'], [count('Catalogo cargado', 1), has('USB-001 | Cable')])
t('G7', 'Carga', 'Cambios pendientes; opcion 8; 1=Descartar', 'Recarga el archivo; USB-001 ya no existe',
  ['1', 'USB-001', 'Cable', '1', '1', '8', '1', '3', 'USB-001', '0'], [count('Catalogo cargado', 2), has('Producto no encontrado.')])
def blocktmp(d): os.mkdir(os.path.join(d, 'inventario.tmp'))
t('G8', 'Guardado', 'inventario.tmp bloqueado (carpeta) y opcion 7', 'No se pudo guardar; cambios pendientes; archivo intacto',
  ['5', 'LED-005', '1', '7', '0', '2'], [has('No se pudo guardar', 'Hay cambios sin guardar'), stockof('LED-005', 30)], prep=blocktmp)
t('G9', 'Salida', 'Venta y salir con 1=Guardar y salir', 'Guarda y termina; LED-005 en 29',
  ['5', 'LED-005', '1', '0', '1'], [has('Catalogo guardado'), stockof('LED-005', 29)])
t('G10', 'Salida', 'Venta y salir con 2=Salir sin guardar', 'Termina; archivo sin cambios',
  ['5', 'LED-005', '1', '0', '2'], [stockof('LED-005', 30)])
L = txtfile(BASE).decode().split('\r\n')[:-1]
def T_(lines, end='\r\n'): return (end.join(lines) + end).encode()
bad_files = [
    ('archivo binario de la U2 (inventario.dat)', binfile(BASE)),
    ('11 productos', T_(['AAA-%03d|1.00|1|P' % k for k in range(11)])),
    ('linea sin nombre (faltan campos)', T_([L[0], 'BAD-001|1.00|1'])),
    ('precio 0', T_([L[0], 'BAD-001|0|1|X'])),
    ('precio 10000', T_([L[0], 'BAD-001|10000|1|X'])),
    ('precio con 3 decimales', T_([L[0], 'BAD-001|1.234|1|X'])),
    ('existencia 101', T_([L[0], 'BAD-001|1.00|101|X'])),
    ('existencia no numerica', T_([L[0], 'BAD-001|1.00|1a|X'])),
    ('codigo en minusculas', T_([L[0], 'bad-001|1.00|1|X'])),
    ('codigo de 8 caracteres', T_([L[0], 'BAD-0011|1.00|1|X'])),
    ('codigo repetido', T_([L[0], L[1], L[0]])),
    ('nombre de 26 caracteres', T_([L[0], 'BAD-001|1.00|1|' + 'A' * 26])),
    ('nombre solo con espacios', T_([L[0], 'BAD-001|1.00|1|   '])),
    ('archivo de mas de 599 bytes', T_([L[0] + ' ' * 600])),
]
for k, (name, data) in enumerate(bad_files, 1):
    t('F%d' % k, 'Archivo', 'Cargar inventario.txt con %s' % name, 'Rechazado; catalogo vacio',
      ['2', '0'], [has('No se pudo cargar', 'Catalogo vacio.')], initial=data)
k = len(bad_files)
t('F%d' % (k + 1), 'Archivo', 'inventario.txt vacio (0 bytes)', 'Aceptado; catalogo vacio',
  ['2', '0'], [has('Catalogo cargado y validado.', 'Catalogo vacio.')], initial=b'')
t('F%d' % (k + 2), 'Archivo', 'Saltos LF de Bloc de notas, lineas vacias y ultima linea sin salto', 'Aceptado; 3 productos',
  ['6', '0'], [has('Catalogo cargado y validado.', 'Unidades disponibles: 44')],
  initial=('\n' + L[0] + '\n\n' + L[1] + '\r\n' + L[2]).encode())
t('F%d' % (k + 3), 'Archivo', 'Nombre con caracter | (ABC-001|1.00|5|Cable A|B)', 'Aceptado; nombre "Cable A|B"',
  ['3', 'ABC-001', '0'], [has('ABC-001 | Cable A|B')], initial=T_(['ABC-001|1.00|5|Cable A|B']))
t('T1', 'Guardado', 'Alta USB-001 (Cable USB, 12.05, 6) y guardar', 'inventario.txt legible con 4 lineas CODIGO|PRECIO|EXISTENCIA|NOMBRE',
  ['1', 'USB-001', 'Cable USB', '12.05', '6', '7', '0'],
  [fileeq(txtfile(BASE + [('USB-001', 'Cable USB', 1205, 6)]))])
# --- Regla adicional ---
t('N1', 'Regla adicional', 'Venta ESP-032 x 4 (queda 6)', 'Sin alerta', ['5', 'ESP-032', '4', '0', '2'], [has('Existencia: 6'), hasnot('ALERTA')])
t('N2', 'Regla adicional', 'Venta ESP-032 x 5 (queda 5)', 'ALERTA: existencia baja', ['5', 'ESP-032', '5', '0', '2'], [has('Existencia: 5', 'ALERTA')])
t('N3', 'Regla adicional', 'Entrada RES-220 + 2 (pasa de 4 a 6)', 'La alerta desaparece', ['4', 'RES-220', '2', '0', '2'],
  [has('Existencia: 6'), hasnot('ALERTA')])
# --- Menu ---
t('M1', 'Menu', 'Opciones 9, x, vacio', '3 veces Dato invalido', ['9', 'x', '', '0'], [count('Dato invalido', 3)])

import re
KEYS = ('Dato invalido', 'Codigo duplicado', 'Operacion aceptada', 'Operacion rechazada', 'Producto no encontrado',
        'Capacidad maxima', 'Importe de la venta', 'Unidades disponibles', 'Valor del inventario', 'Ingresos de esta sesion',
        'ALERTA', 'Catalogo guardado', 'No se pudo guardar', 'Catalogo cargado', 'No se pudo cargar', 'Catalogo vacio',
        'Hay cambios sin guardar')
def summarize(o):
    lines = o.split('\n')
    body = lines[2:] if len(lines) > 2 else lines      # omite el titulo
    first_load = 'Carga inicial: ' + ('valida' if 'Catalogo cargado' in o.split('Opcion')[0] else 'error')
    parts = []; seen = set()
    for l in body:
        l = l.strip()
        for k in KEYS:
            if l.startswith(k):
                if k == 'Dato invalido':
                    continue
                txt = l.split('.')[0] if k not in ('Importe de la venta', 'Unidades disponibles', 'Valor del inventario', 'Ingresos de esta sesion') else l
                if k == 'Hay cambios sin guardar': txt = 'Pide confirmacion por cambios sin guardar'
                if k == 'ALERTA': txt = 'ALERTA de existencia baja'
                if txt not in seen:
                    seen.add(txt); parts.append(txt)
        if l.startswith('Precio:') and 'Existencia' in l:
            txt = l.replace(' | ', ', ')
            if txt not in seen:
                seen.add(txt); parts.append(txt)
    n = o.count('Dato invalido')
    if n: parts.insert(0, 'Dato invalido x%d' % n)
    # quitar la primera aparicion de 'Catalogo cargado' (carga automatica al iniciar)
    return '; '.join(parts)

results = []
ok_all = True
for c in T:
    outs = {}
    raw = isinstance(c['kw'].get('initial', BASE), bytes)
    for k, b in BINS.items():
        if k.startswith('u2') and raw:
            continue
        outs[k] = run(b, c['inputs'], u3=k.startswith('u3'), **c['kw'])
    o, d, rc = outs['u3']
    if raw:
        same = None if outs['u3'][:1] == outs['u3c'][:1] else False
    else:
        same = outs['u2'][0] == outs['u3'][0] == outs['u2c'][0] == outs['u3c'][0]
    passed = rc == 0 and all(ch(o, d) for ch in c['checks'])
    ok_all &= passed and same is not False
    results.append(dict(id=c['id'], parte=c['parte'], entrada=c['entrada'], esperado=c['esperado'],
                        obtenido=(summarize(o) if passed else 'FALLO: ' + summarize(o)), igual_u2=same))
    print('%-4s %-16s %-6s U2==U3:%s' % (c['id'], c['parte'], 'OK' if passed else 'FALLO', same))
    if not passed or same is False:
        print(o[-1500:])
json.dump(results, open(os.path.join(ROOT, 'evidencias', 'resultados_pruebas_u3.json'), 'w'), ensure_ascii=False, indent=1)
print('TOTAL', len(T), 'TODO OK' if ok_all else 'HAY FALLOS')
