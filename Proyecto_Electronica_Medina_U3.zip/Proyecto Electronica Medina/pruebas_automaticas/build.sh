#!/bin/bash
# Uso: build.sh fuente.asm salida [stc|clc]
# Traduce el MASM del proyecto a NASM y lo enlaza con un sustituto de
# Irvine32 para ejecutarlo en Linux de 32 bits (solo pruebas de logica).
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
F=${3:-stc}
T=$(mktemp -d)
python3 -I "$DIR/masm2nasm.py" "$1" "$T/p.nasm"
nasm -f elf32 "$T/p.nasm" -o "$T/p.o"
nasm -f elf32 -DFLAGCF=$F "$DIR/irvine_stub.asm" -o "$T/s.o"
ld -m elf_i386 "$T/p.o" "$T/s.o" -o "$2"
rm -rf "$T"
