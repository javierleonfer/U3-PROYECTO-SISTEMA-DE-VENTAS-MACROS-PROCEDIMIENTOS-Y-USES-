#!/usr/bin/env python3
"""Traductor MASM->NASM limitado a los constructos de este proyecto.
Solo sirve para probar la logica en Linux; el proyecto real se ensambla con ML."""
import re, sys, os

src_path = sys.argv[1]
out_path = sys.argv[2]
base = os.path.dirname(os.path.abspath(src_path))

def strip_comment(line):
    out = []; q = None
    for ch in line:
        if q:
            out.append(ch)
            if ch == q: q = None
        elif ch in "'\"":
            q = ch; out.append(ch)
        elif ch == ';':
            break
        else:
            out.append(ch)
    return ''.join(out).rstrip()

def load(path):
    lines = []
    for raw in open(path, encoding='utf-8'):
        l = strip_comment(raw.rstrip('\n'))
        m = re.match(r'\s*INCLUDE\s+(\S+)', l, re.I)
        if m:
            if m.group(1).lower() == 'irvine32.inc':
                continue
            lines += load(os.path.join(os.path.dirname(path), m.group(1)))
            continue
        if l.strip():
            lines.append(l)
    return lines

lines = load(src_path)

# ---------- macros ----------
macros = {}
body = []
i = 0
while i < len(lines):
    m = re.match(r'\s*(\w+)\s+MACRO\b\s*(.*)$', lines[i], re.I)
    if m:
        name = m.group(1).lower()
        params = [p.strip().split(':')[0] for p in m.group(2).split(',') if p.strip()]
        j = i + 1; mb = []
        while not re.match(r'\s*ENDM\b', lines[j], re.I):
            mb.append(lines[j]); j += 1
        macros[name] = (params, mb)
        i = j + 1
        continue
    body.append(lines[i]); i += 1

def split_args(s):
    args = []; cur = ''; depth = 0; q = None
    for ch in s:
        if q:
            cur += ch
            if ch == q: q = None
            continue
        if ch in "'\"": q = ch; cur += ch; continue
        if ch == '<': depth += 1;
        if ch == '>': depth -= 1
        if ch == ',' and depth == 0:
            args.append(cur); cur = ''; continue
        cur += ch
    if cur.strip() or args: args.append(cur)
    res = []
    for a in args:
        a = a.strip()
        if a.startswith('<') and a.endswith('>'): a = a[1:-1]
        res.append(a)
    return res

counter = [0]
def expand(ls):
    out = []
    for l in ls:
        m = re.match(r'\s*(?:(\w+):\s*)?(\w+)\b\s*(.*)$', l)
        if m and m.group(2).lower() in macros:
            if m.group(1): out.append(m.group(1) + ':')
            params, mb = macros[m.group(2).lower()]
            args = split_args(m.group(3))
            args += [''] * (len(params) - len(args))
            sub = dict(zip(params, args))
            mb = list(mb)
            if mb and re.match(r'\s*LOCAL\b', mb[0], re.I):
                for name in re.match(r'\s*LOCAL\s+(.*)', mb[0], re.I).group(1).split(','):
                    sub[name.strip()] = 'L__%04d' % counter[0]; counter[0] += 1
                mb = mb[1:]
            new = []
            for bl in mb:
                for k, v in sub.items():
                    bl = re.sub(r'\b' + re.escape(k) + r'\b', lambda _m, v=v: v, bl)
                new.append(bl)
            out += expand(new)
        else:
            out.append(l)
    return out

body = expand(body)

# ---------- constantes y STRUCT ----------
consts = {'INVALID_HANDLE_VALUE': -1}
structs = {}   # name -> {field:(off,size,type)}, total
TYPES = {'BYTE': 1, 'WORD': 2, 'DWORD': 4}
SZNAME = {1: 'byte', 2: 'word', 4: 'dword'}

def num(expr):
    e = expr
    e = re.sub(r'\b([0-9][0-9A-Fa-f]*)[hH]\b', lambda m: str(int(m.group(1), 16)), e)
    e = re.sub(r'SIZEOF\s+(\w+)', lambda m: str(sizeof(m.group(1))), e, flags=re.I)
    for k in sorted(consts, key=len, reverse=True):
        e = re.sub(r'\b' + k + r'\b', str(consts[k]), e)
    return int(eval(e))

datas = {}  # label -> (elemsize, total, structname)
def sizeof(name):
    if name in structs: return structs[name][1]
    return datas[name][1]

rest = []
i = 0
while i < len(body):
    l = body[i]
    m = re.match(r'\s*(\w+)\s+STRUCT\b', l, re.I)
    if m:
        fields = {}; off = 0; j = i + 1
        while not re.match(r'\s*\w+\s+ENDS\b', body[j], re.I):
            fm = re.match(r'\s*(\w+)\s+(BYTE|WORD|DWORD)\s+(.*)$', body[j], re.I)
            t = TYPES[fm.group(2).upper()]
            d = re.match(r'(.*)\bDUP\b', fm.group(3), re.I)
            n = num(d.group(1)) if d else 1
            fields[fm.group(1)] = (off, t * n, t)
            off += t * n; j += 1
        structs[m.group(1)] = (fields, off)
        i = j + 1; continue
    m = re.match(r'\s*(\w+)\s*=\s*(.*)$', l)
    if m:
        consts[m.group(1)] = num(m.group(2)); i += 1; continue
    rest.append(l); i += 1

# ---------- datos y codigo ----------
out = ['bits 32', 'extern WriteString, Crlf, ReadString, OpenInputFile, CreateOutputFile',
       'extern ReadFromFile, WriteToFile, CloseFile, MoveFileExA, ExitProcess', 'global _start']
for k, v in consts.items():
    out.append('%%define %s %d' % (k, v))

section = None
proc_uses = []
labels_seen = set()

def conv_data(l):
    m = re.match(r'\s*(?:(\w+)\s+)?(BYTE|WORD|DWORD|\w+)\s+(.*)$', l)
    label, typ, vals = m.group(1), m.group(2), m.group(3)
    res = []
    if label: res.append(label + ':')
    if typ.upper() in TYPES:
        t = TYPES[typ.upper()]; d = {1: 'db', 2: 'dw', 4: 'dd'}[t]
        dm = re.match(r'\(?(.*?)\)?\s*DUP\s*\((.*)\)\s*$', vals, re.I)
        if dm:
            n = num(dm.group(1)); res.append('times %d %s %s' % (n, d, dm.group(2)))
            size = n * t
        else:
            items = split_args(vals)
            size = 0
            for it in items:
                size += (len(it) - 2) * t if it.startswith("'") else t
            res.append('%s %s' % (d, ', '.join(items)))
        return label, t, size, res
    st = structs[typ]
    dm = re.match(r'(.*?)\s*DUP', vals, re.I)
    n = num(dm.group(1)) if dm else 1
    res.append('times %d db 0' % (n * st[1]))
    return label, None, n * st[1], res

last_label = None
data_lines = []
code_lines = []
for l in rest:
    s = l.strip()
    if s.lower() == '.data': section = 'data'; continue
    if s.lower() == '.code': section = 'code'; continue
    if section == 'data':
        label, t, size, res = conv_data(l)
        if label:
            datas[label] = (t, size, None); last_label = label
        else:
            datas[last_label] = (datas[last_label][0], datas[last_label][1] + size, None)
        data_lines += res
        continue
    if re.match(r"\s*END\b", l, re.I) or re.search(r"\bPROTO\b", l, re.I): continue
    code_lines.append(l)

for name in ('catalog', 'candidate'):
    datas[name] = ('Product', datas[name][1], 'Product')

def conv_operand(op, other=None):
    op = op.strip()
    f, _ = structs['Product']
    # (Product PTR [reg]).field
    def sf(m):
        off, sz, t = f[m.group(2)]
        return '%s [%s+%d]' % (SZNAME[t] if sz == t else 'byte', m.group(1), off)
    lea_mode = False
    op = re.sub(r'\(Product\s+PTR\s+\[(\w+)\]\)\.(\w+)', sf, op)
    op = re.sub(r'SIZEOF\s+(\w+)', lambda m: str(sizeof(m.group(1))), op, flags=re.I)
    if re.match(r'OFFSET\s+', op, re.I):
        e = op[6:].strip()
        e = re.sub(r'(\w+)\.(\w+)', lambda m: '%s+%d' % (m.group(1), f[m.group(2)][0]), e)
        return e
    m = re.match(r'(BYTE|WORD|DWORD)\s+PTR\s+(.*)$', op, re.I)
    if m:
        t = m.group(1).lower(); e = m.group(2).strip()
        if e.startswith('['): return '%s %s' % (t, e)
        mm = re.match(r'(\w+)\[(.*)\]$', e)
        if mm: return '%s [%s+%s]' % (t, mm.group(1), mm.group(2))
        return '%s [%s]' % (t, e)
    m = re.match(r'(\w+)\.(\w+)$', op)
    if m and m.group(1) in datas:
        off, sz, t = f[m.group(2)]
        return '%s [%s+%d]' % (SZNAME[t], m.group(1), off)
    m = re.match(r'(\w+)\[(.*)\]$', op)
    if m and m.group(1) in datas:
        return '[%s+%s]' % (m.group(1), m.group(2))
    if op in datas and datas[op][0] == 4 and datas[op][1] == 4:
        return 'dword [%s]' % op
    return op

for l in code_lines:
    s = l.strip()
    m = re.match(r'(\w+)\s+PROC\b(.*)$', s, re.I)
    if m:
        proc_uses = re.findall(r'\b(e[a-d]x|e[sd]i|ebp)\b', m.group(2), re.I) if re.search(r'USES', m.group(2), re.I) else []
        out_name = '_start' if m.group(1) == 'main' else m.group(1)
        code_lines_out = out.append if False else None
        out.append(m.group(1) + ':')
        if m.group(1) == 'main': out.append('_start:')
        for r in proc_uses: out.append('    push ' + r)
        continue
    if re.match(r'\w+\s+ENDP', s, re.I): proc_uses = []; continue
    m = re.match(r'(\w+):\s*(.*)$', s)
    if m:
        out.append(m.group(1) + ':'); s = m.group(2)
        if m.group(1) == 'mainMenu':
            # Comprobacion de pila: ESP debe ser igual en cada vuelta del menu.
            out += ['    cmp dword [espSaved],0', '    jne .espc', '    mov [espSaved],esp',
                    '.espc: cmp [espSaved],esp', '    je .espok', '    push 99', '    call ExitProcess', '.espok:']
        if not s: continue
    m = re.match(r'(\w+)\s*(.*)$', s)
    mn, ops = m.group(1).lower(), m.group(2)
    if mn == 'ret':
        for r in reversed(proc_uses): out.append('    pop ' + r)
        out.append('    ret'); continue
    if mn == 'exit':
        out.append('    push 0'); out.append('    call ExitProcess'); continue
    if mn == 'invoke':
        parts = split_args(ops)
        for a in reversed(parts[1:]):
            a = re.sub(r'ADDR\s+', '', a, flags=re.I)
            out.append('    push dword ' + a)
        out.append('    call ' + parts[0]); continue
    parts = split_args(ops) if ops else []
    parts = [conv_operand(p) for p in parts]
    if mn == 'lea':
        parts[1] = re.sub(r'^(byte|word|dword)\s+', '', parts[1])
    out.append('    %s %s' % (mn, ', '.join(parts)))

final = out[:4 + len(consts)] + ['section .data', 'espSaved dd 0'] + data_lines + ['section .text'] + out[4 + len(consts):]
open(out_path, 'w').write('\n'.join(final) + '\n')
