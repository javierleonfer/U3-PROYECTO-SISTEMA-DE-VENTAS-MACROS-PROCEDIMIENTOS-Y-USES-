; Sustituto minimo de Irvine32 para Linux (solo pruebas automaticas).
%ifndef FLAGCF
%define FLAGCF stc
%endif
global WriteString, Crlf, ReadString, OpenInputFile, CreateOutputFile
global ReadFromFile, WriteToFile, CloseFile, MoveFileExA, ExitProcess
section .data
crlf db 13,10
chr  db 0
section .text
WriteString:
    pushad
    mov ecx,edx
    xor edx,edx
.l: cmp byte [ecx+edx],0
    je .w
    inc edx
    jmp .l
.w: mov eax,4
    mov ebx,1
    int 0x80
    popad
    FLAGCF
    ret
Crlf:
    pushad
    mov eax,4
    mov ebx,1
    mov ecx,crlf
    mov edx,2
    int 0x80
    popad
    FLAGCF
    ret
; EDX=buffer, ECX=max caracteres. EAX=caracteres leidos.
ReadString:
    push ebx
    push ecx
    push edx
    push esi
    push edi
    mov esi,edx
    mov edi,ecx
    xor ecx,ecx          ; contador
    push ecx
.next:
    push esi
    mov eax,3
    xor ebx,ebx
    mov ecx,chr
    mov edx,1
    int 0x80
    pop esi
    cmp eax,1
    jne .eof
    mov al,[chr]
    cmp al,13
    je .next
    cmp al,10
    je .done
    pop ecx
    cmp ecx,edi
    jae .skip
    mov [esi+ecx],al
    inc ecx
.skip:
    push ecx
    jmp .next
.eof:
    pop ecx
    test ecx,ecx
    jnz .fin
    mov eax,1
    mov ebx,3
    int 0x80
.done:
    pop ecx
.fin:
    mov byte [esi+ecx],0
    push ecx
    ; eco de la linea leida, como en la consola
    mov eax,4
    mov ebx,1
    mov edx,ecx
    mov ecx,esi
    int 0x80
    mov eax,4
    mov ebx,1
    mov ecx,crlf
    mov edx,2
    int 0x80
    pop eax
    pop edi
    pop esi
    pop edx
    pop ecx
    pop ebx
    FLAGCF
    ret
OpenInputFile:
    push ebx
    mov eax,5
    mov ebx,edx
    xor ecx,ecx
    int 0x80
    test eax,eax
    jns .ok
    mov eax,-1
.ok:pop ebx
    mov ecx,0BADC0DEh       ; simula registros alterados por la API
    mov edx,0BADC0DEh
    FLAGCF
    ret
CreateOutputFile:
    push ebx
    mov eax,5
    mov ebx,edx
    mov ecx,0241h
    mov edx,0644o
    int 0x80
    test eax,eax
    jns .ok
    mov eax,-1
.ok:pop ebx
    mov ecx,0BADC0DEh
    mov edx,0BADC0DEh
    FLAGCF
    ret
ReadFromFile:
    push ebx
    mov ebx,eax
    mov eax,3
    xchg ecx,edx           ; ecx=buffer, edx=cuenta
    int 0x80
    pop ebx
    mov ecx,0BADC0DEh
    mov edx,0BADC0DEh
    test eax,eax
    js .err
    clc
    ret
.err:
    stc
    ret
WriteToFile:
    push ebx
    mov ebx,eax
    mov eax,4
    xchg ecx,edx
    int 0x80
    pop ebx
    mov ecx,0BADC0DEh
    mov edx,0BADC0DEh
    test eax,eax
    js .err
    clc
    ret
.err:
    stc
    ret
CloseFile:
    push ebx
    mov ebx,eax
    mov eax,6
    int 0x80
    pop ebx
    mov ecx,0BADC0DEh
    mov edx,0BADC0DEh
    test eax,eax
    jnz .bad
    mov eax,1
    FLAGCF
    ret
.bad:
    xor eax,eax
    ret
MoveFileExA:              ; stdcall (old,new,flags)
    push ebx
    mov eax,38
    mov ebx,[esp+8]
    mov ecx,[esp+12]
    int 0x80
    pop ebx
    mov ecx,0BADC0DEh
    mov edx,0BADC0DEh
    test eax,eax
    jnz .bad
    mov eax,1
    ret 12
.bad:
    xor eax,eax
    ret 12
ExitProcess:
    mov eax,1
    mov ebx,[esp+4]
    int 0x80
