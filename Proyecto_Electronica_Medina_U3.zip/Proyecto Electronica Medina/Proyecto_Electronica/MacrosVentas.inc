; MacrosVentas.inc - Unidad 3
; Macros del sistema de ventas. Cada macro sustituye una secuencia corta
; que se repetia en main.asm. MASM copia (expande) estas instrucciones en
; cada punto de uso; la reduccion es de codigo fuente, no de bytes.
; El archivo no se llama Macros.inc para no chocar con el de Irvine.

;----------------------------------------------------------------------
; mPrint texto
; Muestra una cadena terminada en cero. Conserva EDX (PUSH/POP propios).
;----------------------------------------------------------------------
mPrint MACRO texto
    push edx
    mov edx,OFFSET texto
    call WriteString
    pop edx
ENDM

;----------------------------------------------------------------------
; mPrintValue texto, valor, rutina
; Muestra una etiqueta y despues un valor con PrintUInt o PrintMoney.
; Modifica EAX (recibe el valor).
;----------------------------------------------------------------------
mPrintValue MACRO texto, valor, rutina
    mPrint texto
    mov eax,valor
    call rutina
ENDM

;----------------------------------------------------------------------
; mRetOK / mRetError
; Regreso con CF=0 (aceptado) o CF=1 (rechazado). Dentro de un PROC con
; USES, MASM genera los POP de USES antes de cada RET.
;----------------------------------------------------------------------
mRetOK MACRO
    clc
    ret
ENDM

mRetError MACRO
    stc
    ret
ENDM

;----------------------------------------------------------------------
; mJmpOutOfRange valor, minimo, maximo, destino
; Salta a destino si valor < minimo o valor > maximo (sin signo).
; Sirve para digitos, letras, caracteres imprimibles, cantidades y precios.
; Solo modifica EFLAGS.
;----------------------------------------------------------------------
mJmpOutOfRange MACRO valor, minimo, maximo, destino
    cmp valor,minimo
    jb destino
    cmp valor,maximo
    ja destino
ENDM

;----------------------------------------------------------------------
; mAppendDigit digito, destino
; EAX = EAX*10 + (digito - '0'). Salta a destino si no cabe en 32 bits.
; Modifica EAX, EDX y el registro digito.
;----------------------------------------------------------------------
mAppendDigit MACRO digito, destino
    sub digito,'0'
    mov edx,10
    mul edx
    test edx,edx
    jnz destino
    add eax,digito
    jc destino
ENDM

;----------------------------------------------------------------------
; mZeroMem direccion, bytes
; Llena con ceros un bloque. Modifica EAX, ECX y EDI.
;----------------------------------------------------------------------
mZeroMem MACRO direccion, bytes
    mov edi,direccion
    mov ecx,bytes
    xor eax,eax
    cld
    rep stosb
ENDM

;----------------------------------------------------------------------
; mCopyMem destino, origen, bytes
; Copia un bloque de bytes. Modifica ECX, ESI y EDI.
;----------------------------------------------------------------------
mCopyMem MACRO destino, origen, bytes
    mov ecx,bytes
    mov esi,origen
    mov edi,destino
    cld
    rep movsb
ENDM

;----------------------------------------------------------------------
; mAskWith mensaje, validador
; Pide un dato con AskValidated hasta que el validador lo acepte.
; Salida EAX segun el validador. Modifica EAX, EDX y EDI.
;----------------------------------------------------------------------
mAskWith MACRO mensaje, validador
    mov edx,OFFSET mensaje
    mov edi,OFFSET validador
    call AskValidated
ENDM

;----------------------------------------------------------------------
; mAskNumber mensaje, minimo, maximo
; Pide un entero sin signo dentro de [minimo, maximo].
; Salida EAX=entero. Modifica EAX, EBX, EDX, EDI y EBP.
;----------------------------------------------------------------------
mAskNumber MACRO mensaje, minimo, maximo
    mov ebx,minimo
    mov ebp,maximo
    mAskWith mensaje, ParseInRange
ENDM

;----------------------------------------------------------------------
; mReportCF textoOK, textoError
; Muestra textoOK si CF=0 o textoError si CF=1. Conserva EFLAGS con
; PUSHFD/POPFD para que el llamador pueda seguir usando CF.
; Usa LOCAL porque tiene etiquetas internas y se expande en varios puntos.
;----------------------------------------------------------------------
mReportCF MACRO textoOK, textoError
    LOCAL reportBad, reportDone
    pushfd
    jc reportBad
    mPrint textoOK
    jmp reportDone
reportBad:
    mPrint textoError
reportDone:
    popfd
ENDM

;----------------------------------------------------------------------
; mPutChar caracter
; Escribe un caracter en [EDI] y avanza EDI. Se usa al armar las lineas
; de inventario.txt. Modifica EDI.
;----------------------------------------------------------------------
mPutChar MACRO caracter
    mov BYTE PTR [edi],caracter
    inc edi
ENDM

;----------------------------------------------------------------------
; mStoreHandle destino
; Despues de OpenInputFile/CreateOutputFile: salta a destino si EAX es
; INVALID_HANDLE_VALUE; si no, guarda el manejador en fileHandle.
;----------------------------------------------------------------------
mStoreHandle MACRO destino
    cmp eax,INVALID_HANDLE_VALUE
    je destino
    mov fileHandle,eax
ENDM

;----------------------------------------------------------------------
; mCloseHandle
; Cierra fileHandle. Salida EAX distinto de cero si se cerro bien.
;----------------------------------------------------------------------
mCloseHandle MACRO
    mov eax,fileHandle
    call CloseFile
ENDM
