; Materia: Lenguajes de Interfaz - Unidad 3
; Alumno: León Fernández Alexis Javier | Matrícula: 23171137
; Docente: Ing. José Luis Medina Jiménez | Horario: 8:00 - 9:00
; Proyecto: Electronica Medina - ventas e inventario, MASM x86 / Irvine32.
; Version U3: procedimientos reutilizables, macros (MacrosVentas.inc),
; constantes y estructura en Electronica.inc, y USES en los procedimientos.
; Convencion: USES conserva los registros enumerados. Los registros que
; entregan resultados (EAX y, donde se indica, ESI o EDX) NO van en USES.
; EFLAGS se modifica; CF=1 significa error o rechazo. No hay conversiones
; de Irvine: los numeros y el dinero se convierten con rutinas propias.

INCLUDE Irvine32.inc
INCLUDE Electronica.inc
INCLUDE MacrosVentas.inc

.data
catalog Product MAX_PRODUCTS DUP(<>)
productCount DWORD 0
sessionIncome DWORD 0
dirty DWORD 0
candidate Product <>
tempCatalog Product MAX_PRODUCTS DUP(<>) ; catalogo leido del archivo, antes de aceptarlo
fileBuffer BYTE FILE_MAX DUP(0)          ; texto completo de inventario.txt
fileHandle DWORD 0
fileLength DWORD 0
fileCount DWORD 0
inventoryPath BYTE 'inventario.txt',0
temporaryPath BYTE 'inventario.tmp',0
inputBuffer BYTE 256 DUP(0)
numberBuffer BYTE 16 DUP(0)
moneyBuffer BYTE 24 DUP(0)
fieldBuffer BYTE 16 DUP(0)               ; precio o existencia de una linea del archivo

; Tabla de opciones 1 a 8 del menu (la opcion 0 se atiende en main).
menuTable DWORD DoRegister, ShowInventory, DoFind, DoReceive
          DWORD DoSell, ShowSummary, SaveWithMessage, DoLoad

titleText BYTE 13,10,'ELECTRONICA MEDINA - Inventario y ventas',13,10,0
menuText BYTE 13,10,'1. Registrar producto',13,10,'2. Mostrar inventario',13,10
 BYTE '3. Buscar por codigo',13,10,'4. Recibir mercancia',13,10,'5. Vender',13,10
 BYTE '6. Resumen y alertas',13,10,'7. Guardar catalogo',13,10
 BYTE '8. Cargar catalogo',13,10,'0. Salir',13,10,'Opcion: ',0
promptCode BYTE 'Codigo (ABC-123): ',0
askName BYTE 'Nombre (1 a 25 caracteres): ',0
askPrice BYTE 'Precio en MXN (0.01 a 9999.99): ',0
askStock BYTE 'Existencia inicial (0 a 100): ',0
askQuantity BYTE 'Cantidad entera (1 a 100): ',0
invalidText BYTE 'Dato invalido. Intenta de nuevo.',13,10,0
duplicateText BYTE 'Codigo duplicado. Captura otro codigo.',13,10,0
fullText BYTE 'Capacidad maxima: diez productos.',13,10,0
notFoundText BYTE 'Producto no encontrado.',13,10,0
okText BYTE 'Operacion aceptada.',13,10,0
rejectedText BYTE 'Operacion rechazada: limite, existencias o desbordamiento. Sin cambios.',13,10,0
emptyText BYTE 'Catalogo vacio.',13,10,0
dividerText BYTE ' | ',0
priceText BYTE 'Precio: ',0
stockText BYTE 'Existencia: ',0
mxnText BYTE ' MXN',0
saleText BYTE 'Importe de la venta: ',0
unitsText BYTE 'Unidades disponibles: ',0
valueText BYTE 'Valor del inventario: ',0
incomeText BYTE 'Ingresos de esta sesion: ',0
alertText BYTE 'ALERTA: existencia baja (5 unidades o menos).',13,10,0
savedText BYTE 'Catalogo guardado correctamente.',13,10,0
loadedText BYTE 'Catalogo cargado y validado.',13,10,0
loadErrorText BYTE 'No se pudo cargar: archivo ausente, inaccesible o invalido. Catalogo sin cambios.',13,10,0
saveErrorText BYTE 'No se pudo guardar. Se conservan los cambios pendientes.',13,10,0
pendingText BYTE 'Hay cambios sin guardar. 1=Guardar y salir, 2=Salir sin guardar, 0=Volver: ',0
loadPendingText BYTE 'Hay cambios sin guardar. 1=Descartar y cargar, 0=Volver: ',0

.code

;======================================================================
; CAPTURA Y CONVERSION
;======================================================================

; ReadInput (modificado: USES reducido a los registros que si cambian)
; Recibe EDX=mensaje. Devuelve EAX=longitud, inputBuffer=cadena y CF=1 si
; se alcanzo el limite conservador de 250. Conserva ECX y EDX con USES;
; Irvine conserva los demas. Nunca valida un prefijo truncado.
ReadInput PROC USES ecx edx
    call WriteString
    mov edx,OFFSET inputBuffer
    mov ecx,SIZEOF inputBuffer - 1
    call ReadString
    cmp eax,250                  ; tambien rechaza truncados de Irvine antiguo
    jae riBad
    mRetOK
riBad:
    mRetError
ReadInput ENDP

; AskValidated (NUEVO: sustituye los ciclos de AskCode, nombre, precio y
; AskUnsigned de la U2).
; Recibe EDX=mensaje y EDI=OFFSET del procedimiento validador. El
; validador recibe ESI=inputBuffer y devuelve CF=1 si el dato no sirve.
; Repite "Dato invalido" hasta obtener un dato valido.
; Devuelve EAX = valor del validador; si el validador conserva EAX, queda
; la longitud leida por ReadInput. EAX es salida: no va en USES.
; Conserva ESI (USES); EBX, ECX, EDX, EDI y EBP no se modifican.
AskValidated PROC USES esi
avAgain:
    call ReadInput
    jc avBad
    mov esi,OFFSET inputBuffer
    call edi                     ; validador elegido por el llamador
    jnc avDone
avBad:
    mPrint invalidText
    jmp avAgain
avDone:
    ret
AskValidated ENDP

; ParseUnsigned (modificado: usa mJmpOutOfRange y mAppendDigit)
; Recibe ESI=cadena terminada en cero. Devuelve EAX=DWORD sin signo y CF=1
; si esta vacia, tiene algo distinto de 0-9 o desborda 32 bits.
; Conserva EBX, ECX, EDX y ESI con USES.
ParseUnsigned PROC USES ebx ecx edx esi
    xor eax,eax
    xor ecx,ecx
puLoop:
    movzx ebx,BYTE PTR [esi]
    test ebx,ebx
    jz puEnd
    mJmpOutOfRange ebx,'0','9',puBad
    mAppendDigit ebx,puBad
    inc esi
    inc ecx
    jmp puLoop
puEnd:
    test ecx,ecx
    jz puBad
    mRetOK
puBad:
    mRetError
ParseUnsigned ENDP

; ParseInRange (NUEVO: validador para AskValidated)
; Recibe ESI=cadena, EBX=minimo y EBP=maximo. Devuelve EAX=entero y CF=1
; si no es entero o esta fuera de rango. Solo modifica EAX (salida), sin
; USES porque no altera otros registros.
ParseInRange PROC
    call ParseUnsigned
    jc pirBad
    mJmpOutOfRange eax,ebx,ebp,pirBad
    mRetOK
pirBad:
    mRetError
ParseInRange ENDP

; ParsePrice (modificado: macros de rango y digito)
; Recibe ESI=precio en pesos. Devuelve EAX=centavos [1,999999], CF=error.
; Exige al menos un digito entero; permite cero, uno o dos decimales.
; Conserva EBX, ECX, EDX, ESI, EDI y EBP con USES. Sin coma flotante.
ParsePrice PROC USES ebx ecx edx esi edi ebp
    xor eax,eax
    xor ecx,ecx
ppWhole:
    movzx ebx,BYTE PTR [esi]
    cmp ebx,'.'
    je ppDot
    test ebx,ebx
    jz ppNoFraction
    mJmpOutOfRange ebx,'0','9',ppBad
    mAppendDigit ebx,ppBad
    cmp eax,9999
    ja ppBad
    inc ecx
    inc esi
    jmp ppWhole
ppNoFraction:
    test ecx,ecx
    jz ppBad
    imul eax,eax,100
    jmp ppRange
ppDot:
    test ecx,ecx
    jz ppBad
    imul ebp,eax,100
    inc esi
    xor edi,edi
    xor ecx,ecx
ppFraction:
    movzx ebx,BYTE PTR [esi]
    test ebx,ebx
    jz ppFractionEnd
    mJmpOutOfRange ebx,'0','9',ppBad
    cmp ecx,2
    jae ppBad
    sub ebx,'0'
    imul edi,edi,10
    add edi,ebx
    inc ecx
    inc esi
    jmp ppFraction
ppFractionEnd:
    test ecx,ecx
    jz ppBad
    cmp ecx,1
    jne ppTwo
    imul edi,edi,10
ppTwo:
    mov eax,ebp
    add eax,edi
    jc ppBad
ppRange:
    mJmpOutOfRange eax,1,MAX_PRICE,ppBad
    mRetOK
ppBad:
    mRetError
ParsePrice ENDP

;======================================================================
; VALIDACION
;======================================================================

; ValidateCode (modificado: mJmpOutOfRange para letras y digitos)
; Recibe ESI=cadena con al menos 8 bytes accesibles. CF=0 si es ABC-123
; exacto (tambien comprueba el terminador). Conserva EAX, ECX y ESI.
ValidateCode PROC USES eax ecx esi
    mov ecx,3
vcLetters:
    mov al,[esi]
    mJmpOutOfRange al,'A','Z',vcBad
    inc esi
    loop vcLetters
    cmp BYTE PTR [esi],'-'
    jne vcBad
    inc esi
    mov ecx,3
vcDigits:
    mov al,[esi]
    mJmpOutOfRange al,'0','9',vcBad
    inc esi
    loop vcDigits
    cmp BYTE PTR [esi],0
    jne vcBad
    mRetOK
vcBad:
    mRetError
ValidateCode ENDP

; ValidateName (modificado: mJmpOutOfRange para ASCII imprimible)
; Recibe ESI=nombre. CF=0 si tiene de 1 a 25 caracteres imprimibles y al
; menos uno distinto de espacio. Conserva EAX, EBX, ECX y ESI.
ValidateName PROC USES eax ebx ecx esi
    xor ecx,ecx
    xor ebx,ebx
vnLoop:
    mov al,[esi]
    test al,al
    jz vnEnd
    cmp ecx,25
    jae vnBad
    mJmpOutOfRange al,32,126,vnBad
    cmp al,32
    je vnSpace
    inc ebx
vnSpace:
    inc esi
    inc ecx
    jmp vnLoop
vnEnd:
    test ebx,ebx
    jz vnBad
    mRetOK
vnBad:
    mRetError
ValidateName ENDP

; ValidateRecord (modificado: rango de precio con macro)
; Recibe ESI=producto. CF=0 si codigo, nombre, relleno, reservado,
; precio y existencia son validos. Conserva EAX, ECX, ESI y EDI.
ValidateRecord PROC USES eax ecx esi edi
    call ValidateCode
    jc vrBad
    lea edi,(Product PTR [esi]).productName
    push esi
    mov esi,edi
    call ValidateName
    pop esi
    jc vrBad
    ; Exigir ceros despues del primer terminador del nombre.
    mov ecx,NAME_SIZE
    xor eax,eax
vrPadding:
    cmp BYTE PTR [edi],0
    jne vrNonzero
    mov eax,1
    jmp vrNext
vrNonzero:
    test eax,eax
    jnz vrBad
vrNext:
    inc edi
    loop vrPadding
    cmp (Product PTR [esi]).reserved,0
    jne vrBad
    mJmpOutOfRange <(Product PTR [esi]).price>,1,MAX_PRICE,vrBad
    cmp (Product PTR [esi]).stock,MAX_STOCK
    ja vrBad
    mRetOK
vrBad:
    mRetError
ValidateRecord ENDP

;======================================================================
; CADENAS Y SALIDA NUMERICA
;======================================================================

; StrAppend (NUEVO: base de StrCopy y de las lineas del archivo de texto)
; Recibe ESI=cadena origen terminada en cero y EDI=destino. Copia la
; cadena SIN el cero. Devuelve EDI = siguiente byte libre (EDI es salida,
; no va en USES). Conserva EAX y ESI con USES.
StrAppend PROC USES eax esi
saLoop:
    mov al,[esi]
    test al,al
    jz saDone
    mov [edi],al
    inc esi
    inc edi
    jmp saLoop
saDone:
    ret
StrAppend ENDP

; StrCopy (NUEVO: reemplaza tres copias manuales)
; Recibe ESI=cadena origen terminada en cero y EDI=destino. Copia la
; cadena incluido el cero. Conserva EDI con USES (StrAppend conserva EAX y ESI).
StrCopy PROC USES edi
    call StrAppend
    mov BYTE PTR [edi],0
    ret
StrCopy ENDP

; UIntToString (sin cambios de logica)
; Recibe EAX=entero y EDI=buffer de 11 bytes como minimo. Escribe el
; decimal con cero final. Conserva EAX, EBX, ECX, EDX y EDI.
; Cada PUSH de un residuo tiene su POP: pila equilibrada incluso para 0.
UIntToString PROC USES eax ebx ecx edx edi
    mov ebx,10
    xor ecx,ecx
utsDivide:
    xor edx,edx
    div ebx
    push edx
    inc ecx
    test eax,eax
    jnz utsDivide
utsWrite:
    pop edx
    add dl,'0'
    mov [edi],dl
    inc edi
    loop utsWrite
    mov BYTE PTR [edi],0
    ret
UIntToString ENDP

; AmountToString (NUEVO: antes era parte de MoneyToString)
; Recibe EAX=centavos y EDI=buffer de al menos 15 bytes. Escribe
; "pesos.xx" con cero final; se usa en pantalla y en el archivo de texto.
; Conserva EAX, EBX, ECX, EDX, EDI y ESI con USES.
AmountToString PROC USES eax ebx ecx edx edi esi
    xor edx,edx
    mov ebx,100
    div ebx
    push edx                     ; centavos; se recupera abajo (pila equilibrada)
    call UIntToString
    mov esi,edi
atsEnd:
    cmp BYTE PTR [esi],0
    je atsFraction
    inc esi
    jmp atsEnd
atsFraction:
    mov BYTE PTR [esi],'.'
    pop eax
    xor edx,edx
    mov ebx,10
    div ebx
    add al,'0'
    add dl,'0'
    mov [esi+1],al
    mov [esi+2],dl
    mov BYTE PTR [esi+3],0
    ret
AmountToString ENDP

; MoneyToString (modificado: usa AmountToString y agrega " MXN")
; Recibe EAX=centavos y EDI=buffer de al menos 19 bytes. Escribe
; "pesos.xx MXN". Conserva EDI y ESI con USES.
MoneyToString PROC USES edi esi
    call AmountToString
mtsEnd:
    cmp BYTE PTR [edi],0
    je mtsSuffix
    inc edi
    jmp mtsEnd
mtsSuffix:
    mov esi,OFFSET mxnText
    call StrCopy
    ret
MoneyToString ENDP

; PrintUInt (modificado: mPrint)
; Recibe EAX=entero y lo muestra. Conserva EDI con USES (EAX y EDX no cambian).
PrintUInt PROC USES edi
    mov edi,OFFSET numberBuffer
    call UIntToString
    mPrint numberBuffer
    ret
PrintUInt ENDP

; PrintMoney (modificado: mPrint)
; Recibe EAX=centavos y muestra "pesos.xx MXN". Conserva EDI con USES.
PrintMoney PROC USES edi
    mov edi,OFFSET moneyBuffer
    call MoneyToString
    mPrint moneyBuffer
    ret
PrintMoney ENDP

;======================================================================
; CATALOGO Y REGLAS DEL NEGOCIO
;======================================================================

; CodesEqual (NUEVO: comparacion de codigos usada en busqueda y archivo)
; Recibe ESI y EDI apuntando a codigos de 8 bytes. Devuelve ZF=1 si son
; iguales. Conserva EAX con USES; los POP de USES no alteran ZF.
CodesEqual PROC USES eax
    mov eax,[esi]
    cmp eax,[edi]
    jne ceDone
    mov eax,[esi+4]
    cmp eax,[edi+4]
ceDone:
    ret
CodesEqual ENDP

; FindCode (NUEVO: busqueda en cualquier tabla de productos)
; Recibe EDX=codigo, ESI=primer registro de la tabla y ECX=cantidad de
; registros. Devuelve EAX=puntero al registro con ese codigo o cero.
; EAX es salida (fuera de USES). Conserva ECX, ESI y EDI.
FindCode PROC USES ecx esi edi
    mov edi,edx
fcLoop:
    test ecx,ecx
    jz fcMissing
    call CodesEqual
    je fcFound
    add esi,PRODUCT_SIZE
    dec ecx
    jmp fcLoop
fcFound:
    mov eax,esi
    ret
fcMissing:
    xor eax,eax
    ret
FindCode ENDP

; FindProduct (modificado: usa FindCode sobre el catalogo)
; Recibe EDX=codigo. Devuelve EAX=puntero a Product o cero.
; EAX es salida (fuera de USES). Conserva ECX y ESI.
FindProduct PROC USES ecx esi
    mov esi,OFFSET catalog
    mov ecx,productCount
    call FindCode
    ret
FindProduct ENDP

; ForEachProduct (NUEVO: recorrido comun de inventario y alertas)
; Recibe EBX=OFFSET de un procedimiento que recibe ESI=producto y que
; conserva EBX, ECX y ESI. Lo llama una vez por producto.
; Conserva ECX y ESI con USES.
ForEachProduct PROC USES ecx esi
    mov esi,OFFSET catalog
    mov ecx,productCount
fepLoop:
    test ecx,ecx
    jz fepDone
    call ebx
    add esi,PRODUCT_SIZE
    dec ecx
    jmp fepLoop
fepDone:
    ret
ForEachProduct ENDP

; IsLowStock (sin cambios)
; Recibe ESI=producto. Devuelve CF=1 si stock<=5 (regla adicional).
; No modifica registros.
IsLowStock PROC
    cmp (Product PTR [esi]).stock,LOW_STOCK
    ja ilsNormal
    stc
    ret
ilsNormal:
    clc
    ret
IsLowStock ENDP

; ReceiveStock (modificado: mJmpOutOfRange; USES solo con EBX)
; Recibe ESI=producto y EAX=cantidad. CF=1 si se rechaza. Solo cambia
; stock y dirty cuando todas las comprobaciones pasan. Conserva EBX.
ReceiveStock PROC USES ebx
    mJmpOutOfRange eax,1,MAX_STOCK,rsBad
    mov ebx,(Product PTR [esi]).stock
    add ebx,eax
    jc rsBad
    cmp ebx,MAX_STOCK
    ja rsBad
    mov (Product PTR [esi]).stock,ebx
    mov dirty,1
    mRetOK
rsBad:
    mRetError
ReceiveStock ENDP

; SellProduct (modificado: mJmpOutOfRange)
; Recibe ESI=producto y EAX=cantidad. Devuelve EAX=importe y CF=1 si se
; rechaza. EAX es salida: no va en USES. Conserva EBX, ECX y EDX.
; Los ingresos se comprueban ANTES de descontar stock.
SellProduct PROC USES ebx ecx edx
    mJmpOutOfRange eax,1,MAX_STOCK,spBad
    cmp eax,(Product PTR [esi]).stock
    ja spBad
    mov ecx,eax
    mul (Product PTR [esi]).price
    test edx,edx
    jnz spBad
    mov ebx,sessionIncome
    add ebx,eax
    jc spBad
    sub (Product PTR [esi]).stock,ecx
    mov sessionIncome,ebx
    mov dirty,1
    mRetOK
spBad:
    mRetError
SellProduct ENDP

; ComputeSummary (modificado: PRODUCT_SIZE y macros de regreso)
; Sin entradas. Devuelve EAX=unidades, EDX=valor en centavos, CF=error.
; EAX y EDX son salida (fuera de USES). Conserva EBX, ECX, ESI, EDI, EBP.
ComputeSummary PROC USES ebx ecx esi edi ebp
    xor edi,edi
    xor ebp,ebp
    mov esi,OFFSET catalog
    mov ecx,productCount
csLoop:
    test ecx,ecx
    jz csDone
    mov eax,(Product PTR [esi]).stock
    add edi,eax
    jc csBad
    mul (Product PTR [esi]).price
    test edx,edx
    jnz csBad
    add ebp,eax
    jc csBad
    add esi,PRODUCT_SIZE
    dec ecx
    jmp csLoop
csDone:
    mov eax,edi
    mov edx,ebp
    mRetOK
csBad:
    mRetError
ComputeSummary ENDP

; RegisterCandidate (modificado: mCopyMem)
; Recibe candidate completo. CF=1 si es invalido, duplicado o no cabe.
; Copia el registro y publica el contador al final.
; Conserva EAX, ECX, EDX, ESI y EDI con USES.
RegisterCandidate PROC USES eax ecx edx esi edi
    cmp productCount,MAX_PRODUCTS
    jae rcBad
    mov esi,OFFSET candidate
    call ValidateRecord
    jc rcBad
    mov edx,OFFSET candidate
    call FindProduct
    test eax,eax
    jnz rcBad
    mov eax,productCount
    imul eax,PRODUCT_SIZE
    lea edi,catalog[eax]
    mCopyMem edi, OFFSET candidate, PRODUCT_SIZE
    inc productCount
    mov dirty,1
    mRetOK
rcBad:
    mRetError
RegisterCandidate ENDP

;======================================================================
; ARCHIVO inventario.txt (texto)
;======================================================================

; Formato de inventario.txt (una linea por producto, se lee en el Bloc de notas):
;     CODIGO|PRECIO|EXISTENCIA|NOMBRE
;     ESP-032|185.50|10|ESP32 DevKit
; El nombre va al final para que pueda contener cualquier caracter imprimible.

; ReadField (NUEVO: lee un campo de una linea de texto)
; Recibe ESI=texto, EDI=destino, ECX=caracteres maximos (sin el cero) y
; BL=separador ('|'); con BL=0 el campo llega hasta el fin de la linea.
; Copia el campo con cero final y avanza ESI despues del separador o del
; salto de linea. Devuelve CF=1 si el campo es demasiado largo o no
; termina como se esperaba. ESI es salida (fuera de USES).
; Conserva EAX, ECX y EDI con USES.
ReadField PROC USES eax ecx edi
rfLoop:
    mov al,[esi]
    test al,al
    jz rfEnd
    cmp al,13
    je rfEnd
    cmp al,10
    je rfEnd
    test bl,bl
    jz rfStore
    cmp al,bl
    je rfEnd
rfStore:
    test ecx,ecx
    jz rfBad                     ; el campo no cabe
    mov [edi],al
    inc edi
    inc esi
    dec ecx
    jmp rfLoop
rfEnd:
    mov BYTE PTR [edi],0
    test bl,bl
    jz rfEndOfLine
    cmp al,bl                    ; falta el separador
    jne rfBad
    inc esi
    mRetOK
rfEndOfLine:
    cmp al,13
    jne rfLf
    inc esi
    mov al,[esi]
rfLf:
    cmp al,10
    jne rfLast
    inc esi
    mRetOK
rfLast:
    test al,al                   ; ultima linea sin salto
    jnz rfBad
    mRetOK
rfBad:
    mRetError
ReadField ENDP

; ParseLine (NUEVO: convierte una linea del archivo en un Product)
; Recibe ESI=inicio de la linea y EDI=registro destino lleno de ceros.
; Usa ReadField, ParsePrice, ParseUnsigned y ValidateRecord, asi que el
; archivo pasa por las mismas validaciones que la captura en consola.
; Devuelve ESI = inicio de la siguiente linea (salida) y CF=1 si es invalida.
; Conserva EAX, EBX, ECX, EDX y EDI con USES.
ParseLine PROC USES eax ebx ecx edx edi
    mov edx,edi                  ; EDX = registro destino
    mov bl,'|'
    mov ecx,CODE_SIZE - 1
    call ReadField               ; codigo -> productCode
    jc plBad
    mov edi,OFFSET fieldBuffer
    mov ecx,SIZEOF fieldBuffer - 1
    call ReadField               ; precio en texto
    jc plBad
    push esi
    mov esi,OFFSET fieldBuffer
    call ParsePrice
    pop esi
    jc plBad
    mov (Product PTR [edx]).price,eax
    mov ecx,SIZEOF fieldBuffer - 1
    call ReadField               ; existencia en texto (EDI sigue en fieldBuffer)
    jc plBad
    push esi
    mov esi,OFFSET fieldBuffer
    call ParseUnsigned
    pop esi
    jc plBad
    mov (Product PTR [edx]).stock,eax
    mov bl,0
    lea edi,(Product PTR [edx]).productName
    mov ecx,NAME_SIZE - 1
    call ReadField               ; nombre hasta el fin de la linea
    jc plBad
    push esi
    mov esi,edx
    call ValidateRecord
    pop esi
    jc plBad
    mRetOK
plBad:
    mRetError
ParseLine ENDP

; ParseTextFile (NUEVO: reemplaza a ValidateFile del formato binario)
; Recibe EAX=bytes leidos en fileBuffer. Llena tempCatalog y fileCount solo
; si todas las lineas son validas, hay 10 productos o menos y no hay codigos
; repetidos. Se permiten lineas vacias. CF=1 si el archivo es invalido.
; No cambia el catalogo. Conserva todos los registros con USES.
ParseTextFile PROC USES eax ebx ecx edx esi edi
    cmp eax,SIZEOF fileBuffer - 1
    jae ptBad                    ; archivo demasiado grande
    mov BYTE PTR fileBuffer[eax],0
    lea ebx,fileBuffer[eax]      ; EBX = fin del texto
    mZeroMem OFFSET tempCatalog, CATALOG_SIZE
    mov esi,OFFSET fileBuffer
    mov edi,OFFSET tempCatalog
    xor ecx,ecx                  ; ECX = productos leidos
ptLoop:
    cmp esi,ebx
    jae ptDone
    mov al,[esi]
    cmp al,13
    je ptSkip
    cmp al,10
    je ptSkip
    cmp ecx,MAX_PRODUCTS
    jae ptBad
    call ParseLine
    jc ptBad
    push esi
    mov edx,edi                  ; codigo recien leido
    mov esi,OFFSET tempCatalog
    call FindCode                ; busca entre los ECX anteriores
    pop esi
    test eax,eax
    jnz ptBad                    ; codigo repetido
    add edi,PRODUCT_SIZE
    inc ecx
    jmp ptLoop
ptSkip:
    inc esi
    jmp ptLoop
ptDone:
    mov fileCount,ecx
    mRetOK
ptBad:
    mRetError
ParseTextFile ENDP

; AppendUInt (NUEVO) Recibe EAX=entero y EDI=destino. Escribe el numero
; sin cero final y devuelve EDI despues de el (salida). Conserva ESI.
AppendUInt PROC USES esi
    push edi
    mov edi,OFFSET numberBuffer
    call UIntToString
    pop edi
    mov esi,OFFSET numberBuffer
    call StrAppend
    ret
AppendUInt ENDP

; AppendAmount (NUEVO) Recibe EAX=centavos y EDI=destino. Escribe
; "pesos.xx" sin cero final y devuelve EDI despues (salida). Conserva ESI.
AppendAmount PROC USES esi
    push edi
    mov edi,OFFSET moneyBuffer
    call AmountToString
    pop edi
    mov esi,OFFSET moneyBuffer
    call StrAppend
    ret
AppendAmount ENDP

; FormatLine (NUEVO) Recibe ESI=producto y EDI=destino. Escribe
; "CODIGO|PRECIO|EXISTENCIA|NOMBRE" y CR LF. Devuelve EDI = siguiente
; byte libre (salida). Conserva EAX, EBX y ESI con USES.
FormatLine PROC USES eax ebx esi
    mov ebx,esi                  ; EBX = producto
    call StrAppend               ; el codigo esta al inicio del registro
    mPutChar '|'
    mov eax,(Product PTR [ebx]).price
    call AppendAmount
    mPutChar '|'
    mov eax,(Product PTR [ebx]).stock
    call AppendUInt
    mPutChar '|'
    lea esi,(Product PTR [ebx]).productName
    call StrAppend
    mPutChar 13
    mPutChar 10
    ret
FormatLine ENDP

; LoadCatalog (modificado: lee texto; mStoreHandle, mCloseHandle, mCopyMem)
; Lee inventario.txt de la carpeta de trabajo. CF=1 si falla.
; Conserva registros e ingresos de la sesion. Valida todo antes de
; reemplazar el catalogo. Las rutinas de archivo de Irvine/Windows pueden
; alterar ECX y EDX, por eso se conservan con USES.
LoadCatalog PROC USES eax ebx ecx edx esi edi
    mov edx,OFFSET inventoryPath
    call OpenInputFile
    mStoreHandle lcBad
    mov edx,OFFSET fileBuffer
    mov ecx,SIZEOF fileBuffer - 1
    call ReadFromFile
    jc lcReadBad
    mov fileLength,eax
    mCloseHandle
    test eax,eax
    jz lcBad
    mov eax,fileLength
    call ParseTextFile
    jc lcBad
    mCopyMem OFFSET catalog, OFFSET tempCatalog, CATALOG_SIZE
    mov eax,fileCount
    mov productCount,eax
    mov dirty,0
    mRetOK
lcReadBad:
    mCloseHandle
lcBad:
    mRetError
LoadCatalog ENDP

; SaveCatalog (modificado: escribe texto con FormatLine)
; Guarda el catalogo. CF=1 si falla. Arma el texto en fileBuffer, lo
; vuelve a validar con ParseTextFile, escribe primero inventario.tmp,
; comprueba bytes y cierre, y reemplaza el destino con MoveFileExA. El
; archivo anterior no se trunca. dirty solo se limpia tras el exito.
; Conserva EAX, EBX, ECX, EDX, ESI y EDI con USES.
SaveCatalog PROC USES eax ebx ecx edx esi edi
    mov edi,OFFSET fileBuffer
    mov esi,OFFSET catalog
    mov ecx,productCount
scLine:
    test ecx,ecx
    jz scText
    call FormatLine              ; EDI avanza una linea
    add esi,PRODUCT_SIZE
    dec ecx
    jmp scLine
scText:
    mov eax,edi
    sub eax,OFFSET fileBuffer
    mov fileLength,eax
    call ParseTextFile           ; comprobacion antes de escribir
    jc scBad
    mov edx,OFFSET temporaryPath
    call CreateOutputFile
    mStoreHandle scBad
    mov edx,OFFSET fileBuffer
    mov ecx,fileLength
    call WriteToFile
    jc scWriteBad
    cmp eax,fileLength
    jne scWriteBad
    mCloseHandle
    test eax,eax
    jz scBad
    INVOKE MoveFileExA,ADDR temporaryPath,ADDR inventoryPath,MOVE_FLAGS
    test eax,eax
    jz scBad
    mov dirty,0
    mRetOK
scWriteBad:
    mCloseHandle
scBad:
    mRetError
SaveCatalog ENDP

;======================================================================
; OPCIONES DEL MENU
;======================================================================

; AskCode (modificado: usa mAskWith/AskValidated)
; Sin entradas. Deja un codigo ABC-123 valido en inputBuffer.
; Conserva EAX, EDX y EDI con USES.
AskCode PROC USES eax edx edi
    mAskWith promptCode, ValidateCode
    ret
AskCode ENDP

; SelectProduct (modificado: mPrint)
; Sin entradas. Devuelve EAX=puntero al producto o cero (con mensaje).
; EAX es salida. Conserva EDX con USES.
SelectProduct PROC USES edx
    call AskCode
    mov edx,OFFSET inputBuffer
    call FindProduct
    test eax,eax
    jnz selDone
    mPrint notFoundText
selDone:
    ret
SelectProduct ENDP

; AskProductQuantity (NUEVO: parte comun de recibir mercancia y vender)
; Sin entradas. Pide codigo y cantidad de 1 a 100.
; Devuelve CF=1 si el producto no existe; si existe, ESI=producto y
; EAX=cantidad. ESI y EAX son salida: quedan fuera de USES.
; Conserva EBX, EDX, EDI y EBP (los modifica mAskNumber).
AskProductQuantity PROC USES ebx edx edi ebp
    call SelectProduct
    test eax,eax
    jz apqMissing
    mov esi,eax
    mAskNumber askQuantity, 1, MAX_STOCK
    mRetOK
apqMissing:
    mRetError
AskProductQuantity ENDP

; DoRegister (modificado: mAskWith, StrCopy, mAskNumber, mReportCF)
; Sin entradas. Captura y registra un producto. Conserva registros.
DoRegister PROC USES eax ebx ecx edx esi edi ebp
    cmp productCount,MAX_PRODUCTS
    jb drStart
    mPrint fullText
    ret
drStart:
    mZeroMem OFFSET candidate, PRODUCT_SIZE
drCode:
    call AskCode
    mov edx,OFFSET inputBuffer
    call FindProduct
    test eax,eax
    jz drCodeOk
    mPrint duplicateText
    jmp drCode
drCodeOk:
    mov esi,OFFSET inputBuffer
    mov edi,OFFSET candidate.productCode
    call StrCopy
    mAskWith askName, ValidateName
    mov esi,OFFSET inputBuffer
    mov edi,OFFSET candidate.productName
    call StrCopy
    mAskWith askPrice, ParsePrice
    mov candidate.price,eax
    mAskNumber askStock, 0, MAX_STOCK
    mov candidate.stock,eax
    call RegisterCandidate
    mReportCF okText, rejectedText
    ret
DoRegister ENDP

; ShowProduct (modificado: mPrint y mPrintValue)
; Recibe ESI=producto. Muestra la ficha y la alerta si corresponde.
; Conserva EAX y EDX con USES.
ShowProduct PROC USES eax edx
    mov edx,esi
    call WriteString
    mPrint dividerText
    lea edx,(Product PTR [esi]).productName
    call WriteString
    call Crlf
    mPrintValue priceText, <(Product PTR [esi]).price>, PrintMoney
    mPrint dividerText
    mPrintValue stockText, <(Product PTR [esi]).stock>, PrintUInt
    call Crlf
    call IsLowStock
    jnc shpDone
    mPrint alertText
shpDone:
    ret
ShowProduct ENDP

; ShowIfLowStock (NUEVO: callback de ForEachProduct para el resumen)
; Recibe ESI=producto. Muestra la ficha solo si aplica la alerta.
; No modifica registros (ShowProduct conserva los suyos).
ShowIfLowStock PROC
    call IsLowStock
    jnc silDone
    call ShowProduct
silDone:
    ret
ShowIfLowStock ENDP

; ShowInventory (modificado: usa ForEachProduct)
; Sin entradas. Muestra todo el inventario. Conserva EBX con USES.
ShowInventory PROC USES ebx
    cmp productCount,0
    jne siStart
    mPrint emptyText
    ret
siStart:
    mov ebx,OFFSET ShowProduct
    call ForEachProduct
    ret
ShowInventory ENDP

; DoFind (NUEVO: la opcion 3 sale de main para usar la tabla del menu)
; Sin entradas. Busca y muestra un producto. Conserva EAX y ESI.
DoFind PROC USES eax esi
    call SelectProduct
    test eax,eax
    jz dfDone
    mov esi,eax
    call ShowProduct
dfDone:
    ret
DoFind ENDP

; DoReceive (modificado: AskProductQuantity y mReportCF)
; Sin entradas. Recibe mercancia. Conserva EAX y ESI con USES.
DoReceive PROC USES eax esi
    call AskProductQuantity
    jc dreDone
    call ReceiveStock
    mReportCF okText, rejectedText
    jc dreDone                   ; mReportCF conserva CF
    call ShowProduct
dreDone:
    ret
DoReceive ENDP

; DoSell (modificado: AskProductQuantity y mPrintValue)
; Sin entradas. Vende un producto. Conserva EAX y ESI con USES.
DoSell PROC USES eax esi
    call AskProductQuantity
    jc dsDone
    call SellProduct
    jc dsReject
    mPrintValue saleText, eax, PrintMoney
    call Crlf
    call ShowProduct
    ret
dsReject:
    mPrint rejectedText
dsDone:
    ret
DoSell ENDP

; ShowSummary (modificado: mPrintValue y ForEachProduct)
; Sin entradas. Muestra totales y productos con existencia baja.
; Conserva EAX, EBX y EDX con USES (EFLAGS cambia).
ShowSummary PROC USES eax ebx edx
    call ComputeSummary
    jc ssBad
    mov ebx,edx
    mPrintValue unitsText, eax, PrintUInt
    call Crlf
    mPrintValue valueText, ebx, PrintMoney
    call Crlf
    mPrintValue incomeText, sessionIncome, PrintMoney
    call Crlf
    mov ebx,OFFSET ShowIfLowStock
    call ForEachProduct
    ret
ssBad:
    mPrint rejectedText
    ret
ShowSummary ENDP

; SaveWithMessage (modificado: mReportCF)
; Sin entradas. Guarda e informa. Devuelve CF=resultado del guardado.
; No necesita USES: mReportCF conserva EDX y EFLAGS.
SaveWithMessage PROC
    call SaveCatalog
    mReportCF savedText, saveErrorText
    ret
SaveWithMessage ENDP

; LoadWithMessage (modificado: mReportCF)
; Sin entradas. Carga e informa. Conserva registros e ingresos.
LoadWithMessage PROC
    call LoadCatalog
    mReportCF loadedText, loadErrorText
    ret
LoadWithMessage ENDP

; DoLoad (NUEVO: la opcion 8 sale de main para usar la tabla del menu)
; Sin entradas. Si hay cambios sin guardar pide confirmacion y despues
; carga. Conserva EAX, EBX, EDX, EDI y EBP (los modifica mAskNumber).
DoLoad PROC USES eax ebx edx edi ebp
    cmp dirty,0
    je dlLoad
    mAskNumber loadPendingText, 0, 1
    test eax,eax
    jz dlDone
dlLoad:
    call LoadWithMessage
dlDone:
    ret
DoLoad ENDP

;======================================================================
; PROGRAMA PRINCIPAL
;======================================================================

; Punto de entrada: no retorna; ExitProcess libera el proceso.
; Las opciones 1 a 8 se despachan con menuTable (CALL indirecto).
main PROC
    cld
    mPrint titleText
    call LoadWithMessage
mainMenu:
    mAskNumber menuText, 0, 8
    test eax,eax
    jz mainExit
    dec eax                      ; opcion 1 -> indice 0
    call DWORD PTR menuTable[eax*4]
    jmp mainMenu
mainExit:
    cmp dirty,0
    je mainQuit
    mAskNumber pendingText, 0, 2
    test eax,eax
    jz mainMenu
    cmp eax,2
    je mainQuit
    call SaveWithMessage
    jc mainMenu
mainQuit:
    exit
main ENDP
END main
