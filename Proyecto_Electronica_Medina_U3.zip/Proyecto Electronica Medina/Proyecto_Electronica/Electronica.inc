; Electronica.inc - Unidad 3
; Constantes del negocio, estructura Product y prototipo de la API de
; Windows que usa el guardado. Se incluye desde main.asm.

MoveFileExA PROTO, oldPath:PTR BYTE, newPath:PTR BYTE, flags:DWORD

MAX_PRODUCTS = 10
MAX_PRICE    = 999999            ; centavos (9999.99 MXN)
MAX_STOCK    = 100
LOW_STOCK    = 5                 ; regla adicional: alerta con 5 o menos
FILE_MAX     = 600               ; bytes de inventario.txt (10 lineas de hasta 47)
CODE_SIZE    = 8                 ; ABC-123 + cero final
NAME_SIZE    = 26                ; 25 caracteres + cero final
MOVE_FLAGS   = 9                 ; MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH

Product STRUCT
    productCode BYTE CODE_SIZE DUP(0)
    productName BYTE NAME_SIZE DUP(0)
    reserved WORD 0
    price DWORD 0                ; centavos enteros
    stock DWORD 0
Product ENDS

PRODUCT_SIZE = SIZEOF Product                ; 44 bytes por registro
CATALOG_SIZE = MAX_PRODUCTS * PRODUCT_SIZE   ; 440 bytes
